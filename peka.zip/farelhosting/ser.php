<?php 

$nik = "Results TTm Family";
$sender = "support@farel.host";
?>